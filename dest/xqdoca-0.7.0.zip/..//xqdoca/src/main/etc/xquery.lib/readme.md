xpath and xquery modules and functions

Much from:
https://github.com/rhdunn/xquery-intellij-plugin/tree/f610832d111eece77a4e7d31659610cba598a468/src/plugin-w3/main/resources/builtin

Note `.ignore` required for BaseX parsing